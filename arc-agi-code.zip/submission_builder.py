# submission_builder.py
from __future__ import annotations
from typing import Dict, Any, List, Tuple
import os, sys, json, glob, re
import numpy as np

from components import Grid
from solver_plus import SolverPlus, SolverPlusConfig
from heuristics import heuristics_two_attempts
from rule_miner import infer_rule_and_apply   # NEW

# optional: register extra primitives if present
try:
    import dsl_extra  # noqa: F401
except Exception:
    pass

def _to_np(grid_list: List[List[int]]) -> np.ndarray:
    return np.array(grid_list, dtype=np.int8)

def _load_challenges_json(path: str) -> Dict[str, Dict[str, Any]]:
    with open(path, "r") as f:
        data = json.load(f)
    if isinstance(data, dict) and "challenges" in data and isinstance(data["challenges"], dict):
        return data["challenges"]
    return data

def _solve_symbolic(
    train_pairs: List[Tuple[Grid, Grid]],
    tests: List[Grid],
    beam: int,
    depth: int,
) -> List[List[Grid]]:
    sv = SolverPlus(SolverPlusConfig(beam=beam, max_depth=depth, use_prune=True, use_repair=True))
    return sv.solve_task(train_pairs, tests)

def _ensure_two(preds: List[np.ndarray], H: int, W: int) -> Tuple[List[List[int]], List[List[int]]]:
    """Return two JSON-serializable grids; pad/dup and center-resize if needed."""
    def to_hxw(a: np.ndarray) -> np.ndarray:
        if a.shape == (H, W):
            return a
        # conservative center resize
        out = np.zeros((H, W), dtype=a.dtype)
        h, w = a.shape
        ih = min(H, h); iw = min(W, w)
        sr0 = (h - ih) // 2; sc0 = (w - iw) // 2
        dr0 = (H - ih) // 2; dc0 = (W - iw) // 2
        out[dr0:dr0+ih, dc0:dc0+iw] = a[sr0:sr0+ih, sc0:sc0+iw]
        return out

    if not preds:
        zeros = [[0]*W for _ in range(H)]
        return zeros, zeros
    if len(preds) == 1:
        A = to_hxw(preds[0]).astype(int).tolist()
        return A, A
    A = to_hxw(preds[0]).astype(int).tolist()
    B = to_hxw(preds[1]).astype(int).tolist()
    return A, B

def _collect_attempts(
    train_pairs: List[Tuple[Grid, Grid]],
    tests: List[Grid],
    sym_outs: List[List[Grid]] | None
) -> List[Tuple[np.ndarray, np.ndarray]]:
    """
    Order: symbolic -> rule_miner -> heuristics. Always end with exactly two attempts per test.
    """
    finals: List[Tuple[np.ndarray, np.ndarray]] = []
    # Precompute miner outs once (it returns list aligned to tests)
    miner_outs = infer_rule_and_apply(train_pairs, tests)  # List[List[np.ndarray]]

    for i, x in enumerate(tests):
        H, W = x.data.shape
        chosen: List[np.ndarray] = []

        # 1) symbolic (take up to 2)
        if sym_outs and i < len(sym_outs) and sym_outs[i]:
            for g in sym_outs[i][:2]:
                if hasattr(g, "data"):
                    arr = np.array(g.data, copy=True)
                    # discourage trivial all-zero
                    if (arr != 0).any():
                        chosen.append(arr)

        # 2) miner (fill up)
        if len(chosen) < 2:
            for arr in miner_outs[i]:
                if (arr != 0).any():
                    chosen.append(arr)
                if len(chosen) >= 2:
                    break

        # 3) heuristics (last resort)
        if len(chosen) < 2:
            hs = heuristics_two_attempts(train_pairs, [x])[0]  # [Grid, Grid]
            for g in hs:
                arr = np.array(g.data, copy=True)
                if (arr != 0).any():
                    chosen.append(arr)
                if len(chosen) >= 2:
                    break

        # pad/trim to exactly two and coerce to (H,W)
        a1, a2 = _ensure_two(chosen[:2], H, W)
        finals.append((np.asarray(a1, int), np.asarray(a2, int)))
    return finals

# ----------------------------
# builders
# ----------------------------

def build_from_folder(folder: str, beam: int = 256, depth: int = 2) -> Dict[str, Any]:
    submission: Dict[str, Any] = {}
    files = sorted(glob.glob(os.path.join(folder, "*.json")))
    hex_re = re.compile(r"([0-9a-fA-F]{8})\.json$")

    for p in files:
        m = hex_re.search(os.path.basename(p))
        if not m:
            continue
        task_id = m.group(1)
        with open(p, "r") as f:
            spec = json.load(f)

        train_pairs: List[Tuple[Grid, Grid]] = [
            (Grid(_to_np(pair["input"])), Grid(_to_np(pair["output"])))
            for pair in spec.get("train", [])
        ]
        tests: List[Grid] = [Grid(_to_np(t["input"])) for t in spec.get("test", [])]

        sym_outs = None
        try:
            sym_outs = _solve_symbolic(train_pairs, tests, beam=beam, depth=depth)
        except Exception:
            sym_outs = None

        per_task_out: List[Dict[str, List[List[int]]]] = []
        for (a1, a2) in _collect_attempts(train_pairs, tests, sym_outs):
            per_task_out.append({"attempt_1": a1.astype(int).tolist(),
                                 "attempt_2": a2.astype(int).tolist()})
        submission[task_id] = per_task_out
    return submission

def build_from_challenges(ch_path: str, beam: int = 256, depth: int = 2) -> Dict[str, Any]:
    raw = _load_challenges_json(ch_path)
    submission: Dict[str, Any] = {}

    for task_id, spec in raw.items():
        train_pairs: List[Tuple[Grid, Grid]] = [
            (Grid(_to_np(pair["input"])), Grid(_to_np(pair["output"])))
            for pair in spec.get("train", [])
        ]
        tests: List[Grid] = [Grid(_to_np(t["input"])) for t in spec.get("test", [])]

        sym_outs = None
        try:
            sym_outs = _solve_symbolic(train_pairs, tests, beam=beam, depth=depth)
        except Exception:
            sym_outs = None

        per_task_out: List[Dict[str, List[List[int]]]] = []
        for (a1, a2) in _collect_attempts(train_pairs, tests, sym_outs):
            per_task_out.append({"attempt_1": a1.astype(int).tolist(),
                                 "attempt_2": a2.astype(int).tolist()})
        submission[task_id] = per_task_out
    return submission

# ----------------------------
# CLI
# ----------------------------

USAGE = """
Build ARC Prize submission.json

Usage:
  python -m submission_builder --input <folder|challenges.json> --output submission.json \
                               [--beam 256] [--depth 2]
"""

def main(argv: List[str]) -> int:
    if len(argv) < 3:
        print(USAGE); return 2

    inp = None; outp = None; beam = 256; depth = 2
    i = 1
    while i < len(argv):
        if argv[i] == "--input" and i+1 < len(argv):
            inp = argv[i+1]; i += 2
        elif argv[i] == "--output" and i+1 < len(argv):
            outp = argv[i+1]; i += 2
        elif argv[i] == "--beam" and i+1 < len(argv):
            beam = int(argv[i+1]); i += 2
        elif argv[i] == "--depth" and i+1 < len(argv):
            depth = int(argv[i+1]); i += 2
        else:
            i += 1

    if not inp or not outp:
        print(USAGE); return 2

    if os.path.isdir(inp):
        sub = build_from_folder(inp, beam=beam, depth=depth)
    else:
        sub = build_from_challenges(inp, beam=beam, depth=depth)

    os.makedirs(os.path.dirname(outp) or ".", exist_ok=True)
    with open(outp, "w") as f:
        json.dump(sub, f)
    print(f"Wrote {outp} with {len(sub)} tasks")
    return 0

if __name__ == "__main__":
    raise SystemExit(main(sys.argv))
