# rule_miner.py
from __future__ import annotations
from typing import List, Tuple, Optional
import numpy as np

from components import Grid

# -----------------------
# Small geometry toolbox
# -----------------------

def _rot(arr: np.ndarray, k: int) -> np.ndarray:
    if k % 4 == 0: return arr
    return np.rot90(arr, k % 4)

def _flip(arr: np.ndarray, mode: str) -> np.ndarray:
    if mode == "none": return arr
    if mode == "h":    return np.flip(arr, axis=1)  # left/right
    if mode == "v":    return np.flip(arr, axis=0)  # up/down
    return arr

def _translate(arr: np.ndarray, dr: int, dc: int, H: int, W: int) -> np.ndarray:
    """Zero-padded integer translation into (H,W)."""
    out = np.zeros((H, W), dtype=arr.dtype)
    h, w = arr.shape
    # dest box
    r0 = max(0, dr)
    c0 = max(0, dc)
    r1 = min(H, dr + h)
    c1 = min(W, dc + w)
    if r0 >= r1 or c0 >= c1:
        return out  # out of view
    # src box
    sr0 = max(0, -dr)
    sc0 = max(0, -dc)
    sr1 = sr0 + (r1 - r0)
    sc1 = sc0 + (c1 - c0)
    out[r0:r1, c0:c1] = arr[sr0:sr1, sc0:sc1]
    return out

def _center_resize(arr: np.ndarray, shape: Tuple[int,int]) -> np.ndarray:
    """If bigger -> center-crop; if smaller -> center-pad with zeros."""
    H, W = shape
    h, w = arr.shape
    out = np.zeros((H, W), dtype=arr.dtype)
    ih = min(H, h); iw = min(W, w)
    sr0 = (h - ih) // 2; sc0 = (w - iw) // 2
    dr0 = (H - ih) // 2; dc0 = (W - iw) // 2
    out[dr0:dr0+ih, dc0:dc0+iw] = arr[sr0:sr0+ih, sc0:sc0+iw]
    return out

def _mode_shape(ys: List[np.ndarray]) -> Tuple[int, int]:
    from collections import Counter
    cnt = Counter([y.shape for y in ys])
    return cnt.most_common(1)[0][0]

# -----------------------
# Palette mapping
# -----------------------

def _counts_10x10() -> np.ndarray:
    return np.zeros((10,10), dtype=np.int64)

def _argmax_row(row: np.ndarray) -> int:
    return int(row.argmax()) if row.sum() > 0 else -1

def _build_palette_map(
    pairs: List[Tuple[np.ndarray, np.ndarray]],
) -> np.ndarray:
    """
    Build 10x10 counts from aligned (x->y) pixels across pairs.
    For pairs with differing shapes we use a coarse strategy:
    - center-resize x to y.shape before counting (keeps it simple and robust).
    Returns a LUT of shape (10,) mapping 0..9 -> 0..9 (identity if unknown).
    """
    C = _counts_10x10()
    for x, y in pairs:
        xa = x
        if x.shape != y.shape:
            xa = _center_resize(x, y.shape)
        xv = xa.reshape(-1); yv = y.reshape(-1)
        for a, b in zip(xv, yv):
            if 0 <= a <= 9 and 0 <= b <= 9:
                C[a, b] += 1
    lut = np.arange(10, dtype=np.int8)
    for c in range(10):
        j = _argmax_row(C[c])
        if j >= 0:
            lut[c] = np.int8(j)
    return lut

def _apply_lut(arr: np.ndarray, lut: np.ndarray) -> np.ndarray:
    out = arr.copy()
    mask = (out >= 0) & (out <= 9)
    out[mask] = lut[out[mask]]
    return out

# -----------------------
# Scoring on train pairs
# -----------------------

def _pixel_diff(a: np.ndarray, b: np.ndarray) -> int:
    if a.shape != b.shape:
        return 10**9  # huge penalty for wrong shape
    return int(np.count_nonzero(a != b))

def _fit_translation(
    xin: np.ndarray, yout: np.ndarray, rot_k: int, flip_mode: str,
    lut: np.ndarray, sr: int
) -> Tuple[int, int, int]:
    """
    For a given (rot, flip, lut), search translation (dr,dc) in [-sr,+sr]
    minimizing pixel diff to yout. Return (best_score, dr, dc).
    """
    h, w = yout.shape
    base = _flip(_rot(xin, rot_k), flip_mode)
    best = (10**9, 0, 0)
    for dr in range(-sr, sr+1):
        for dc in range(-sr, sr+1):
            moved = _translate(base, dr, dc, h, w)
            mapped = _apply_lut(moved, lut)
            sc = _pixel_diff(mapped, yout)
            if sc < best[0]:
                best = (sc, dr, dc)
    return best

# -----------------------
# Main miner
# -----------------------

def _infer_global_params(
    train_pairs: List[Tuple[np.ndarray, np.ndarray]],
    shift_range: int = 5
) -> Tuple[int, str, np.ndarray, int, int]:
    """
    Find a single (rot_k, flip_mode, lut, dr, dc) that best explains the pairs.
    We:
      1) build a LUT from coarse aligned pixels,
      2) grid-search rot in {0,1,2,3} and flip in {"none","h","v"},
      3) for each pair, fit (dr,dc) in [-shift_range,+shift_range] and take median,
      4) score across all pairs with that (rot,flip,lut,dr_med,dc_med),
      5) return the best.
    """
    # First LUT from coarse alignment
    lut0 = _build_palette_map(train_pairs)

    best_tuple: Optional[Tuple[int, str, np.ndarray, int, int]] = None
    best_score = 10**12

    for rot_k in (0,1,2,3):
        for flip_mode in ("none", "h", "v"):
            drs, dcs = [], []
            # Fit translations per pair with current (rot,flip,lut0)
            for xin, yout in train_pairs:
                sc, dr, dc = _fit_translation(xin, yout, rot_k, flip_mode, lut0, shift_range)
                drs.append(dr); dcs.append(dc)
            # robust aggregate translation
            dr_med = int(np.median(np.array(drs)))
            dc_med = int(np.median(np.array(dcs)))

            # score this global param set
            total = 0
            for xin, yout in train_pairs:
                h, w = yout.shape
                base = _flip(_rot(xin, rot_k), flip_mode)
                moved = _translate(base, dr_med, dc_med, h, w)
                mapped = _apply_lut(moved, lut0)
                total += _pixel_diff(mapped, yout)

            if total < best_score:
                best_score = total
                best_tuple = (rot_k, flip_mode, lut0.copy(), dr_med, dc_med)

    assert best_tuple is not None
    return best_tuple  # (rot_k, flip_mode, lut, dr, dc)

def _ensure_nontrivial(arrs: List[np.ndarray]) -> List[np.ndarray]:
    """Replace trivial/all-zero with a simple nonzero-fill based on seen palette."""
    out = []
    for a in arrs:
        if (a != 0).any():
            out.append(a)
        else:
            # pick a safe non-zero color (use 1 if nothing better)
            fill = 1
            out.append(np.where(np.ones_like(a, dtype=bool), fill, a))
    return out

def infer_rule_and_apply(
    train_pairs: List[Tuple[Grid, Grid]],
    tests: List[Grid],
    shift_range: int = 5
) -> List[List[np.ndarray]]:
    """
    Learn a single global rule (rot/flip/translate + palette LUT),
    honor output-size changes (use modal train-output shape),
    and return two non-trivial attempts per test as numpy arrays.
    Output: List over tests, each = [attempt1, attempt2]
    """
    # Convert to raw arrays
    xs = [x.data for (x, _) in train_pairs]
    ys = [y.data for (_, y) in train_pairs]
    Hm, Wm = _mode_shape(ys)

    # Fit global params
    rot_k, flip_mode, lut, dr, dc = _infer_global_params(list(zip(xs, ys)), shift_range)

    outs: List[List[np.ndarray]] = []
    for t in tests:
        # candidate 1: learned rule at modal size
        base = _flip(_rot(t.data, rot_k), flip_mode)
        moved = _translate(base, dr, dc, Hm, Wm)
        cand1 = _apply_lut(moved, lut)

        # candidate 2: same rule but with a tiny translation tweak to diversify
        moved2 = _translate(base, dr, dc+1, Hm, Wm)  # shift right by 1
        cand2 = _apply_lut(moved2, lut)

        # ensure non-trivial
        cands = _ensure_nontrivial([cand1, cand2])
        outs.append(cands[:2])
    return outs
