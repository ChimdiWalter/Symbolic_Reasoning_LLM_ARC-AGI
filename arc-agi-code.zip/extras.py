from __future__ import annotations
from typing import Iterable, List, Tuple, Set
import numpy as np

RC = Tuple[int, int]

# -----------------------------
# Neighborhoods & adjacency
# -----------------------------
def neighbors4(r: int, c: int) -> List[RC]:
    return [(r+1,c),(r-1,c),(r,c+1),(r,c-1)]

def neighbors8(r: int, c: int) -> List[RC]:
    return [(r+1,c),(r-1,c),(r,c+1),(r,c-1),
            (r+1,c+1),(r+1,c-1),(r-1,c+1),(r-1,c-1)]

def adjacency4(coords: Iterable[RC]) -> dict:
    S: Set[RC] = set(coords)
    adj = {p: [] for p in S}
    for (r,c) in S:
        for q in neighbors4(r,c):
            if q in S: adj[(r,c)].append(q)
    return adj

def adjacency8(coords: Iterable[RC]) -> dict:
    """Compatibility function expected by pipeline: 8-neighbor adjacency on a set of (r,c)."""
    S: Set[RC] = set(coords)
    adj = {p: [] for p in S}
    for (r,c) in S:
        for q in neighbors8(r,c):
            if q in S: adj[(r,c)].append(q)
    return adj

# -----------------------------
# Coords <-> mask helpers
# -----------------------------
def mask_from_coords(coords: Iterable[RC]) -> np.ndarray:
    coords = list(coords)
    if not coords: return np.zeros((0,0), dtype=bool)
    rs, cs = zip(*coords)
    r0, c0 = min(rs), min(cs)
    r1, c1 = max(rs)+1, max(cs)+1
    m = np.zeros((r1-r0, c1-c0), dtype=bool)
    m[(np.array(rs)-r0, np.array(cs)-c0)] = True
    return m

def coords_from_mask(mask: np.ndarray, offset: RC = (0,0)) -> List[RC]:
    rr, cc = np.where(mask)
    return [(int(r+offset[0]), int(c+offset[1])) for r,c in zip(rr,cc)]

# -----------------------------
# Label connected components in a mask
# -----------------------------
def label_components(mask: np.ndarray, connectivity: int = 4) -> Tuple[np.ndarray, int]:
    H, W = mask.shape
    lab = -np.ones((H,W), dtype=np.int32)
    n = 0
    N = neighbors4 if connectivity == 4 else neighbors8
    for r in range(H):
        for c in range(W):
            if not mask[r,c] or lab[r,c] != -1: continue
            stack = [(r,c)]; lab[r,c] = n
            while stack:
                rr, cc = stack.pop()
                for nr, nc in N(rr,cc):
                    if 0 <= nr < H and 0 <= nc < W and mask[nr,nc] and lab[nr,nc] == -1:
                        lab[nr,nc] = n; stack.append((nr,nc))
            n += 1
    return lab, n

# -----------------------------
# Simple transforms on coords
# -----------------------------
def translate_coords(coords: Iterable[RC], dr: int, dc: int) -> List[RC]:
    return [(r+dr, c+dc) for r,c in coords]

def reflect_coords(coords: Iterable[RC], H: int, W: int, axis: int) -> List[RC]:
    """axis=0 horizontal (flip vertically), axis=1 vertical (flip horizontally)"""
    if axis == 0:
        return [(H-1-r, c) for r,c in coords]
    else:
        return [(r, W-1-c) for r,c in coords]

def rotate_coords_k(coords: Iterable[RC], H: int, W: int, k: int) -> List[RC]:
    """Rotate coords by k*90° within an HxW frame."""
    k %= 4
    if k == 0: return list(coords)
    if k == 1: return [(c, H-1-r) for r,c in coords]
    if k == 2: return [(H-1-r, W-1-c) for r,c in coords]
    return [(W-1-c, r) for r,c in coords]

# -----------------------------
# Utility: palette
# -----------------------------
def palette(arr: np.ndarray) -> Tuple[int, ...]:
    return tuple(int(x) for x in np.unique(arr))


# -----------------------------
# Color adjacency & counts
# -----------------------------
def color_counts(arr: np.ndarray) -> dict:
    """Return {color:int count} for all colors present in the grid."""
    vals, cnts = np.unique(arr.astype(np.int16), return_counts=True)
    return {int(v): int(c) for v, c in zip(vals, cnts)}

def color_adjacency(arr: np.ndarray, include_zero: bool = False) -> dict:
    """
    Build 4-neighborhood color adjacency: {color: set(neighbor_colors)}.
    If include_zero=False, background color 0 is excluded from keys and neighbors.
    """
    H, W = arr.shape
    arr = arr.astype(np.int16)
    adj = {}
    def add_edge(a, b):
        if not include_zero:
            if a == 0 or b == 0:
                return
        if a not in adj: adj[a] = set()
        if b not in adj: adj[b] = set()
        if a != b:
            adj[a].add(b)
            adj[b].add(a)
    for r in range(H):
        for c in range(W):
            v = int(arr[r, c])
            if r+1 < H: add_edge(v, int(arr[r+1, c]))
            if c+1 < W: add_edge(v, int(arr[r, c+1]))
    # ensure all present colors appear (even if isolated)
    for v in np.unique(arr):
        v = int(v)
        if not include_zero and v == 0: 
            continue
        adj.setdefault(v, set())
    return adj

def grid_to_coords_by_color(arr: np.ndarray) -> dict:
    """Return {color: [(r,c), ...]} for all colors present."""
    arr = arr.astype(np.int16)
    out = {}
    for v in np.unique(arr):
        v = int(v)
        rr, cc = np.where(arr == v)
        out[v] = [(int(r), int(c)) for r, c in zip(rr, cc)]
    return out

def contact_map(arr: np.ndarray, include_zero: bool = False) -> np.ndarray:
    """
    Dense adjacency matrix M where M[i,j]=1 if colors i and j touch (4-neighborhood).
    The size is (max_color+1) x (max_color+1). Set row/col to zero for excluded zero if needed.
    """
    adj = color_adjacency(arr, include_zero=True)
    C = int(np.max(arr)) if arr.size else 0
    M = np.zeros((C+1, C+1), dtype=np.uint8)
    for a, bs in adj.items():
        for b in bs:
            M[a, b] = 1
            M[b, a] = 1
    if not include_zero and 0 <= C:
        M[0, :] = 0; M[:, 0] = 0
    return M

# -----------------------------
# Periodicity detection (NumPy-only)
# -----------------------------
def _axis_period(arr: np.ndarray, axis: int, max_period: int | None = None) -> int | None:
    """
    Smallest k>=1 such that arr shifted by k along axis equals arr (strict periodicity).
    Returns None if no period found up to max_period (or dimension-1 if None).
    """
    if arr.size == 0:
        return None
    a = np.swapaxes(arr, 0, axis)  # bring target axis to front
    L = a.shape[0]
    if L <= 1:
        return None
    if max_period is None or max_period > L - 1:
        max_period = L - 1
    # try smallest k first
    for k in range(1, max_period + 1):
        if np.array_equal(a[k:], a[:-k]):
            return k
    return None

def detect_periodicity(arr: np.ndarray, axis: int | None = None, max_period: int | None = None):
    """
    If axis is 0 or 1: return the period (int) or None along that axis.
    If axis is None: return a tuple (period_rows, period_cols).
    """
    if axis is None:
        pr = _axis_period(arr, axis=0, max_period=max_period)
        pc = _axis_period(arr, axis=1, max_period=max_period)
        return (pr, pc)
    elif axis in (0, 1):
        return _axis_period(arr, axis=axis, max_period=max_period)
    else:
        raise ValueError("axis must be None, 0 (rows), or 1 (cols)")

# Convenience variants some pipelines expect
def detect_row_period(arr: np.ndarray, max_period: int | None = None) -> int | None:
    return _axis_period(arr, axis=0, max_period=max_period)

def detect_col_period(arr: np.ndarray, max_period: int | None = None) -> int | None:
    return _axis_period(arr, axis=1, max_period=max_period)

# -----------------------------
# Singleton (1-pixel component) utilities
# -----------------------------
def _has_singletons_mask(mask: np.ndarray, connectivity: int = 4) -> bool:
    """True if the binary mask contains any 1-pixel connected components."""
    H, W = mask.shape
    if not mask.any(): 
        return False
    # A pixel is a singleton if it is foreground and none of its neighbors are foreground
    if connectivity == 4:
        N = [(1,0),(-1,0),(0,1),(0,-1)]
    else:
        N = [(1,0),(-1,0),(0,1),(0,-1),(1,1),(1,-1),(-1,1),(-1,-1)]
    rr, cc = np.where(mask)
    for r, c in zip(rr, cc):
        iso = True
        for dr, dc in N:
            nr, nc = r+dr, c+dc
            if 0 <= nr < H and 0 <= nc < W and mask[nr, nc]:
                iso = False
                break
        if iso:
            return True
    return False

def has_singletons(arr: np.ndarray, include_zero: bool = False, connectivity: int = 4) -> bool:
    """
    Return True if ANY color layer contains 1-pixel components.
    By default background (0) is ignored; set include_zero=True to include it.
    """
    colors = np.unique(arr.astype(np.int16))
    for c in colors:
        if (c == 0) and (not include_zero):
            continue
        mask = (arr == c)
        if _has_singletons_mask(mask, connectivity=connectivity):
            return True
    return False

def singleton_coords_by_color(arr: np.ndarray, include_zero: bool = False, connectivity: int = 4) -> dict:
    """
    Return {color: [(r,c), ...]} for all 1-pixel components (per color).
    Useful for rules like 'remove noise dots' or 'grow singletons'.
    """
    H, W = arr.shape
    out = {}
    if connectivity == 4:
        N = [(1,0),(-1,0),(0,1),(0,-1)]
    else:
        N = [(1,0),(-1,0),(0,1),(0,-1),(1,1),(1,-1),(-1,1),(-1,-1)]
    for c in np.unique(arr.astype(np.int16)):
        if c == 0 and not include_zero:
            continue
        pts = []
        rr, cc = np.where(arr == c)
        for r, col in zip(rr, cc):
            iso = True
            for dr, dc in N:
                nr, nc = r+dr, col+dc
                if 0 <= nr < H and 0 <= nc < W and arr[nr, nc] == c:
                    iso = False
                    break
            if iso:
                pts.append((int(r), int(col)))
        if pts:
            out[int(c)] = pts
    return out

# -----------------------------
# Grid & pair invariants (NumPy-only)
# -----------------------------
def invariants_for_grid(arr: np.ndarray) -> dict:
    """
    Cheap invariants of a single grid.
    Returns a plain dict of ints/bools/tuples (JSON-serializable).
    """
    H, W = arr.shape
    pal = tuple(int(x) for x in np.unique(arr.astype(np.int16)))
    cnt = color_counts(arr)
    adj = color_adjacency(arr, include_zero=False)
    has_single = has_singletons(arr, include_zero=False, connectivity=4)
    # periodicity along rows/cols
    try:
        pr, pc = detect_periodicity(arr, axis=None)
    except Exception:
        pr, pc = (None, None)
    return {
        "shape": (int(H), int(W)),
        "palette": pal,
        "color_counts": cnt,
        "color_adjacency": {int(k): sorted(int(x) for x in v) for k, v in adj.items()},
        "has_singletons": bool(has_single),
        "row_period": int(pr) if pr is not None else None,
        "col_period": int(pc) if pc is not None else None,
    }

def invariants_for_pair(x: np.ndarray, y: np.ndarray) -> dict:
    """
    Cheap invariants that compare input/output grids.
    Designed to be fast and robust for early pruning/heuristics.
    """
    Hx, Wx = x.shape; Hy, Wy = y.shape
    same_shape = (Hx == Hy and Wx == Wy)

    pal_x = tuple(int(v) for v in np.unique(x.astype(np.int16)))
    pal_y = tuple(int(v) for v in np.unique(y.astype(np.int16)))
    set_x, set_y = set(pal_x), set(pal_y)

    cnt_x = color_counts(x)
    cnt_y = color_counts(y)

    # adjacency/contact maps
    adj_x = color_adjacency(x, include_zero=False)
    adj_y = color_adjacency(y, include_zero=False)

    # periodicity deltas
    try:
        prx, pcx = detect_periodicity(x, axis=None)
        pry, pcy = detect_periodicity(y, axis=None)
    except Exception:
        prx = pcx = pry = pcy = None

    return {
        "same_shape": bool(same_shape),
        "shape_in": (int(Hx), int(Wx)),
        "shape_out": (int(Hy), int(Wy)),
        "palette_in": pal_x,
        "palette_out": pal_y,
        "palette_added": sorted(int(v) for v in (set_y - set_x)),
        "palette_removed": sorted(int(v) for v in (set_x - set_y)),
        "color_counts_in": cnt_x,
        "color_counts_out": cnt_y,
        "adjacency_in": {int(k): sorted(int(a) for a in v) for k, v in adj_x.items()},
        "adjacency_out": {int(k): sorted(int(a) for a in v) for k, v in adj_y.items()},
        "row_period_in": int(prx) if prx is not None else None,
        "col_period_in": int(pcx) if pcx is not None else None,
        "row_period_out": int(pry) if pry is not None else None,
        "col_period_out": int(pcy) if pcy is not None else None,
        "has_singletons_in": bool(has_singletons(x, include_zero=False, connectivity=4)),
        "has_singletons_out": bool(has_singletons(y, include_zero=False, connectivity=4)),
    }

# -----------------------------
# Object/grid transform detection
# -----------------------------
def _same_palette_counts(a: np.ndarray, b: np.ndarray) -> bool:
    va, ca = np.unique(a.astype(np.int16), return_counts=True)
    vb, cb = np.unique(b.astype(np.int16), return_counts=True)
    return va.tolist() == vb.tolist() and ca.tolist() == cb.tolist()

def _reflect(arr: np.ndarray, axis: int) -> np.ndarray:
    # axis=0 => horizontal mirror (flip vertically); axis=1 => vertical mirror (flip horizontally)
    return arr[::-1, :] if axis == 0 else arr[:, ::-1]

def _rotate_k(arr: np.ndarray, k: int) -> np.ndarray:
    return np.rot90(arr, k % 4)

def _translation_delta(a: np.ndarray, b: np.ndarray) -> tuple[int,int] | None:
    """If b is a pure wrap-free translation of a, return (dr,dc); else None."""
    if a.shape != b.shape:
        return None
    H, W = a.shape
    # quick reject: palettes/counts must match
    if not _same_palette_counts(a, b):
        return None
    # locate a non-zero anchor in a, find the same color in b and test consistent shift
    rr, cc = np.where(a != 0)
    if rr.size == 0:
        return (0, 0) if np.array_equal(a, b) else None
    ar, ac = int(rr[0]), int(cc[0])
    col = int(a[ar, ac])
    rr2, cc2 = np.where(b == col)
    for br, bc in zip(rr2.tolist(), cc2.tolist()):
        dr, dc = br - ar, bc - ac
        # translate a by (dr,dc) within bounds (no wrap)
        r0, r1 = max(0, dr), min(H, H + dr)
        c0, c1 = max(0, dc), min(W, W + dc)
        A = a[r0:r1, c0:c1]
        r0b, r1b = r0 - dr, r1 - dr
        c0b, c1b = c0 - dc, c1 - dc
        B = b[r0b:r1b, c0b:c1b]
        if A.shape == B.shape and np.array_equal(A, B):
            # also need zeros where we moved from/to
            test = np.zeros_like(a)
            test[r0b:r1b, c0b:c1b] = A
            if np.array_equal(test, b):
                return int(dr), int(dc)
    return None

def detect_object_transform(a: np.ndarray, b: np.ndarray) -> dict:
    """
    Try to explain b from a via simple transforms:
      - translate (no wrap)
      - reflect_h / reflect_v
      - rotate_k in {90,180,270}
      - identity
    Returns: {"type": <str>, "params": {...}}
    """
    if a.shape == b.shape and np.array_equal(a, b):
        return {"type": "identity", "params": {}}

    if a.shape == b.shape:
        # reflections
        if np.array_equal(_reflect(a, 0), b):
            return {"type": "reflect_h", "params": {"axis": 0}}
        if np.array_equal(_reflect(a, 1), b):
            return {"type": "reflect_v", "params": {"axis": 1}}
        # rotations
        for k, deg in ((1, 90), (2, 180), (3, 270)):
            if np.array_equal(_rotate_k(a, k), b):
                return {"type": "rotate", "params": {"k": k, "deg": deg}}
        # translation
        td = _translation_delta(a, b)
        if td is not None:
            dr, dc = td
            return {"type": "translate", "params": {"dr": int(dr), "dc": int(dc)}}

    # if shapes differ, caller likely handles bbox/placement; call it unknown here
    return {"type": "unknown", "params": {}}

# -----------------------------
# Periodicity record & helper
# -----------------------------
from dataclasses import dataclass

@dataclass
class Periodicity:
    """Lightweight container for grid periodicity."""
    row: int | None          # smallest period along rows (None if aperiodic)
    col: int | None          # smallest period along cols (None if aperiodic)
    fundamental_shape: tuple[int, int] | None  # (row_period, col_period) if both exist

def periodicity_from_array(arr: np.ndarray, max_period: int | None = None) -> Periodicity:
    """Compute periodicity along rows/cols and package as Periodicity."""
    pr, pc = detect_periodicity(arr, axis=None, max_period=max_period)
    base = (int(pr), int(pc)) if (pr is not None and pc is not None) else None
    return Periodicity(row=(int(pr) if pr is not None else None),
                       col=(int(pc) if pc is not None else None),
                       fundamental_shape=base)

# -----------------------------
# Generic invariants container
# -----------------------------
class Invariants(dict):
    """
    Lightweight mapping-like container for invariants.
    - Behaves like a dict
    - Also allows attribute-style access (inv.foo)
    """
    def __getattr__(self, key):
        try:
            return self[key]
        except KeyError as e:
            raise AttributeError(key) from e
    def __setattr__(self, key, value):
        # keep dataclass-like feel
        self[key] = value

def pack_invariants(**kwargs) -> Invariants:
    """
    Convenience constructor:
        inv = pack_invariants(grid=invars_grid, pair=invars_pair, notes="…")
    """
    inv = Invariants()
    inv.update(kwargs)
    return inv

# -----------------------------
# 8-neighborhood adjacency (component-level)
# -----------------------------
def adjacency8(obj):
    """
    If obj is a Scene: returns {comp_id: [neighbor_ids...]} where components touch
    in 8-neighborhood (orthogonal or diagonal).
    If obj is a Grid/np.ndarray: returns color adjacency {color: [neighbor_colors...]}.
    """
    import numpy as _np
    # Scene path (what pipeline calls)
    if hasattr(obj, "comps"):
        scene = obj
        # recover shape from component bboxes
        H = int(max((int(c.bbox[2]) for c in scene.comps), default=0))
        W = int(max((int(c.bbox[3]) for c in scene.comps), default=0))
        lab = -_np.ones((H, W), dtype=_np.int32)
        for i, comp in enumerate(scene.comps):
            rrcc = comp.pixels
            lab[(rrcc[:,0], rrcc[:,1])] = i
        # 8-neigh edges
        adj = {i: set() for i in range(len(scene.comps))}
        def _add_edges(a, b):
            m = (a != b) & (a >= 0) & (b >= 0)
            if not m.any(): return
            us = a[m].ravel(); vs = b[m].ravel()
            for u, v in zip(us.tolist(), vs.tolist()):
                if u != v:
                    adj[u].add(v); adj[v].add(u)
        if W > 1:
            _add_edges(lab[:, :-1], lab[:, 1:])        # right
        if H > 1:
            _add_edges(lab[:-1, :], lab[1:, :])        # down
        if H > 1 and W > 1:
            _add_edges(lab[:-1, :-1], lab[1:, 1:])     # down-right
            _add_edges(lab[:-1, 1:],  lab[1:, :-1])    # down-left
        return {i: sorted(v) for i, v in adj.items()}
    # Grid / ndarray fallback → color adjacency
    arr = obj.data if hasattr(obj, "data") else _np.asarray(obj, dtype=_np.int16)
    arr = arr.astype(_np.int16)
    H, W = arr.shape
    adj = {}
    def _edge(a, b):
        if a == b: return
        adj.setdefault(int(a), set()).add(int(b))
        adj.setdefault(int(b), set()).add(int(a))
    # right, down, diagonals
    if W > 1:
        a, b = arr[:, :-1], arr[:, 1:]
        m = a != b
        if m.any():
            for u, v in zip(a[m].ravel().tolist(), b[m].ravel().tolist()):
                _edge(u, v)
    if H > 1:
        a, b = arr[:-1, :], arr[1:, :]
        m = a != b
        if m.any():
            for u, v in zip(a[m].ravel().tolist(), b[m].ravel().tolist()):
                _edge(u, v)
    if H > 1 and W > 1:
        a, b = arr[:-1, :-1], arr[1:, 1:]
        m = a != b
        if m.any():
            for u, v in zip(a[m].ravel().tolist(), b[m].ravel().tolist()):
                _edge(u, v)
        a, b = arr[:-1, 1:], arr[1:, :-1]
        m = a != b
        if m.any():
            for u, v in zip(a[m].ravel().tolist(), b[m].ravel().tolist()):
                _edge(u, v)
    return {k: sorted(v) for k, v in adj.items()}

# -----------------------------
# Color adjacency (Scene/Grid/ndarray) with 4/8-neighborhood
# Back-compat: accepts (obj, include_zero=False, use8=False)
# -----------------------------
def color_adjacency(obj, include_zero: bool = False, use8: bool = False):
    """
    Returns {color: sorted(list(neighbor_colors))}.
    - obj can be a Scene, Grid, or ndarray.
    - include_zero: whether to include background (0) in the map.
    - use8: if True, use 8-neighborhood; otherwise use 4-neighborhood.
    """
    import numpy as _np

    # normalize to ndarray of ints
    if hasattr(obj, "data"):                     # Grid
        arr = _np.asarray(obj.data, dtype=_np.int16)
    elif hasattr(obj, "comps"):                  # Scene
        # reconstruct array from components
        H = int(max((int(c.bbox[2]) for c in obj.comps), default=0))
        W = int(max((int(c.bbox[3]) for c in obj.comps), default=0))
        arr = _np.zeros((H, W), dtype=_np.int16)
        for c in obj.comps:
            rr, cc = c.pixels[:,0], c.pixels[:,1]
            arr[(rr, cc)] = int(getattr(c, "color", 0))
    else:                                        # ndarray
        arr = _np.asarray(obj, dtype=_np.int16)

    H, W = arr.shape
    adj: dict[int, set[int]] = {}

    def _edge(a, b):
        if not include_zero and (a == 0 or b == 0):
            return
        if a == b:
            return
        a = int(a); b = int(b)
        adj.setdefault(a, set()).add(b)
        adj.setdefault(b, set()).add(a)

    # 4-neigh: right / down
    if W > 1:
        a, b = arr[:, :-1], arr[:, 1:]
        m = a != b
        if m.any():
            for u, v in zip(a[m].ravel().tolist(), b[m].ravel().tolist()):
                _edge(u, v)
    if H > 1:
        a, b = arr[:-1, :], arr[1:, :]
        m = a != b
        if m.any():
            for u, v in zip(a[m].ravel().tolist(), b[m].ravel().tolist()):
                _edge(u, v)

    # 8-neigh diagonals if requested
    if use8 and H > 1 and W > 1:
        a, b = arr[:-1, :-1], arr[1:, 1:]
        m = a != b
        if m.any():
            for u, v in zip(a[m].ravel().tolist(), b[m].ravel().tolist()):
                _edge(u, v)
        a, b = arr[:-1, 1:], arr[1:, :-1]
        m = a != b
        if m.any():
            for u, v in zip(a[m].ravel().tolist(), b[m].ravel().tolist()):
                _edge(u, v)

    # ensure keys for isolated colors (optional; only if they appear)
    if include_zero or 0 in arr:
        for c in _np.unique(arr):
            c = int(c)
            if include_zero or c != 0:
                adj.setdefault(c, set())

    return {k: sorted(v) for k, v in adj.items()}

# -----------------------------
# Robust periodicity helpers (accept Grid/ndarray)
# -----------------------------
def _as_array(obj):
    import numpy as _np
    if hasattr(obj, "data"):                    # Grid
        return _np.asarray(obj.data, dtype=_np.int16)
    return _np.asarray(obj, dtype=_np.int16)    # ndarray

def _axis_period(arr, axis: int = 0, max_period: int | None = None):
    import numpy as _np
    arr = _as_array(arr)
    if arr.size == 0:
        return None
    H, W = arr.shape
    L = H if axis == 0 else W
    if max_period is None:
        max_period = min(10, L)  # small but fine for ARC grids

    # check smallest p such that each row/col repeats with shift p
    for p in range(1, max_period + 1):
        ok = True
        if axis == 0:
            for k in range(p, H):
                if not _np.array_equal(arr[k, :], arr[k - p, :]):
                    ok = False
                    break
        else:
            for k in range(p, W):
                if not _np.array_equal(arr[:, k], arr[:, k - p]):
                    ok = False
                    break
        if ok:
            return p
    return None

def detect_periodicity(obj, axis: int | None = None, max_period: int | None = None):
    """Return row/col periods (or just one if axis provided). Accepts Grid/ndarray."""
    arr = _as_array(obj)
    pr = _axis_period(arr, axis=0, max_period=max_period)
    pc = _axis_period(arr, axis=1, max_period=max_period)
    if axis == 0:
        return pr
    if axis == 1:
        return pc
    return pr, pc

# -----------------------------
# Singleton detector (Scene/Grid/ndarray)
# -----------------------------
def has_singletons(obj, include_zero: bool = False, connectivity: int = 4) -> bool:
    """
    Return True iff there exists a 4-connected component of area 1.
    - Accepts Scene, Grid, or ndarray.
    - If include_zero=False (default), ignores background 0.
    """
    import numpy as np

    # Normalize to ndarray
    arr = _as_array(obj) if ' _as_array' in globals() else (obj.data if hasattr(obj, "data") else np.asarray(obj))
    arr = np.asarray(arr, dtype=np.int16)
    H, W = arr.shape
    if H == 0 or W == 0:
        return False

    # For each cell, check if any same-colored 4-neighbor exists; if none, it's a singleton.
    # (This is equivalent to testing whether the 4-connected component has area == 1.)
    for r in range(H):
        for c in range(W):
            col = int(arr[r, c])
            if not include_zero and col == 0:
                continue
            # Check 4-neighbors for same color
            same = False
            if r > 0   and int(arr[r-1, c]) == col: same = True
            elif r+1 < H and int(arr[r+1, c]) == col: same = True
            elif c > 0   and int(arr[r, c-1]) == col: same = True
            elif c+1 < W and int(arr[r, c+1]) == col: same = True
            if not same:
                return True
    return False
